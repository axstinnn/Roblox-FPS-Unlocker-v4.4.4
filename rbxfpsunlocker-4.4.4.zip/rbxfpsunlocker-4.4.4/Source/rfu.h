#pragma once

#define RFU_VERSION "4.4.4"
#define RFU_GITHUB_REPO "axstin/rbxfpsunlocker"

bool CheckForUpdates();
void SetFPSCapExternal(double value);
